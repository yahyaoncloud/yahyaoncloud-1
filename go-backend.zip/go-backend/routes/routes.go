package routes

import (
	"os"

	"go-backend/handlers"
	"go-backend/middleware"

	routes "go-backend/routes/auth"

	"github.com/gorilla/mux"
)

func RegisterRoutes(r *mux.Router) {
	api := r.PathPrefix("/api").Subrouter()

	// ---------- 🔓 Public Routes ----------
	// Posts - Public Read
	api.HandleFunc("/posts", handlers.GetPosts).Methods("GET")
	api.HandleFunc("/posts/{id}", handlers.GetPostByID).Methods("GET")
	api.HandleFunc("/posts/{CatId}", handlers.GetPostsByCategory).Methods("GET")

	// Comments - Public
	api.HandleFunc("/comments", handlers.GetComments).Methods("GET")
	api.HandleFunc("/comments", handlers.CreateComment).Methods("POST")

	// Portfolio - Public Read
	api.HandleFunc("/portfolio", handlers.GetPortfolio).Methods("GET")
	api.HandleFunc("/categories", handlers.GetCategories).Methods("GET")
	api.HandleFunc("/tags", handlers.GetTags).Methods("GET")

	// Types - Public Read
	api.HandleFunc("/types", handlers.GetTypes).Methods("GET")

	// ---------- 🔐 Admin (JWT Protected) ----------
	admin := api.PathPrefix("").Subrouter()
	admin.Use(middleware.AuthMiddleware(os.Getenv("JWT_SECRET")))
	
	// Admin-only Posts
	admin.HandleFunc("/posts", handlers.CreatePost).Methods("POST")
	admin.HandleFunc("/posts/{id}", handlers.UpdatePost).Methods("PUT")
	admin.HandleFunc("/posts/{id}", handlers.DeletePost).Methods("DELETE")
	
	// Admin-only Categories
	admin.HandleFunc("/categories", handlers.CreateCategory).Methods("POST")
	admin.HandleFunc("/categories", handlers.UpdateCategory).Methods("PUT")
	admin.HandleFunc("/categories", handlers.DeleteCategory).Methods("DELETE")
	
	// Admin-only Tags
	admin.HandleFunc("/tags", handlers.CreateTag).Methods("POST")
	admin.HandleFunc("/tags", handlers.UpdateTag).Methods("PUT")
	admin.HandleFunc("/tags", handlers.DeleteTag).Methods("DELETE")
	
	// Admin-only Portfolio Update
	admin.HandleFunc("/portfolio", handlers.UpdatePortfolio).Methods("PUT")
	
	// Admin login route (no middleware)
	r.HandleFunc("/api/admin/login", handlers.AdminLoginHandler).Methods("POST")
	
	// Admin-only Types
	api.HandleFunc("/types", handlers.CreateType).Methods("POST")
	api.HandleFunc("/types", handlers.DeleteType).Methods("DELETE")

	// ----------- Github OAuth -----------
	auth := api.PathPrefix("/auth/github").Subrouter() // Changed to use /api prefix
	auth.HandleFunc("/login", routes.GitHubLoginRedirectHandler(os.Getenv("GITHUB_CLIENT_ID"))).Methods("GET")
	auth.HandleFunc("/callback", routes.GitHubCallbackHandler(
		os.Getenv("GITHUB_CLIENT_ID"),
		os.Getenv("GITHUB_CLIENT_SECRET"),
		os.Getenv("JWT_SECRET"),
		os.Getenv("ALLOWED_GITHUB_USERNAME"),
	)).Methods("GET")
	api.HandleFunc("/validate-token", handlers.ValidateTokenHandler).Methods("GET")
}