package auth

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/rs/zerolog/log"
)

type GitHubAccessTokenResponse struct {
	AccessToken string `json:"access_token"`
}

type GitHubUser struct {
	Login string `json:"login"`
	Email string `json:"email"`
}

// GitHubLoginRedirectHandler godoc
// @Summary      Redirect to GitHub login
// @Description  Redirects the user to GitHub OAuth login page
// @Tags         Auth
// @Accept       json
// @Produce      json
// @Success      302  {string}  string  "Redirect to GitHub OAuth"
// @Router       /auth/github/login [get]
func GitHubLoginRedirectHandler(clientID string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Info().
			Str("method", r.Method).
			Str("path", r.URL.Path).
			Msg("Redirecting to GitHub OAuth login")
		redirectURL := fmt.Sprintf("https://github.com/login/oauth/authorize?client_id=%s&scope=user:email", clientID)
		http.Redirect(w, r, redirectURL, http.StatusTemporaryRedirect)
	}
}

// GitHubCallbackHandler godoc
// @Summary      GitHub OAuth Callback
// @Description  Exchanges GitHub OAuth code for access token, verifies user, and returns JWT
// @Tags         Auth
// @Accept       json
// @Produce      json
// @Param        code  query  string  true  "OAuth code from GitHub"
// @Success      200   {object}  map[string]string  "JWT Token Response"
// @Failure      400   {string}  string  "Missing code"
// @Failure      401   {string}  string  "Unauthorized GitHub user"
// @Failure      500   {string}  string  "Internal Server Error"
// @Router       /auth/github/callback [get]
func GitHubCallbackHandler(clientID, clientSecret, jwtSecret, allowedUser string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Info().
			Str("method", r.Method).
			Str("path", r.URL.Path).
			Str("query", r.URL.RawQuery).
			Msg("Processing GitHub OAuth callback")

		// Validate environment variables
		if clientID == "" || clientSecret == "" || jwtSecret == "" || allowedUser == "" {
			log.Error().
				Str("client_id", clientID).
				Str("client_secret", clientSecret).
				Str("jwt_secret", jwtSecret).
				Str("allowed_user", allowedUser).
				Msg("Missing required environment variables")
			http.Error(w, "Server configuration error", http.StatusInternalServerError)
			return
		}

		code := r.URL.Query().Get("code")
		if code == "" {
			log.Error().Msg("Missing code in callback request")
			http.Error(w, "Missing code", http.StatusBadRequest)
			return
		}

		// Exchange code for token
		tokenResp, err := exchangeCodeForToken(clientID, clientSecret, code)
		if err != nil {
			log.Error().Err(err).Msg("Failed to exchange code for token")
			http.Error(w, "Failed to get token", http.StatusInternalServerError)
			return
		}
		log.Info().Str("access_token", "[REDACTED]").Msg("Successfully exchanged code for token")

		// Fetch user
		user, err := fetchGitHubUser(tokenResp.AccessToken)
		if err != nil {
			log.Error().Err(err).Msg("Failed to fetch GitHub user")
			http.Error(w, "Failed to fetch user", http.StatusInternalServerError)
			return
		}
		log.Info().Str("username", user.Login).Str("email", user.Email).Msg("Fetched GitHub user")

		// Validate GitHub username
		if user.Login != allowedUser {
			log.Warn().Str("username", user.Login).Str("allowed_user", allowedUser).Msg("Unauthorized GitHub user")
			http.Error(w, "Unauthorized GitHub user", http.StatusUnauthorized)
			return
		}

		// Issue JWT
		claims := jwt.MapClaims{
			"username": user.Login,
			"email":    user.Email,
			"exp":      time.Now().Add(24 * time.Hour).Unix(),
		}
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
		tokenStr, err := token.SignedString([]byte(jwtSecret))
		if err != nil {
			log.Error().Err(err).Msg("Failed to sign JWT")
			http.Error(w, "Token signing error", http.StatusInternalServerError)
			return
		}
		log.Info().Str("username", user.Login).Msg("Issued JWT token")

		// Respond with JWT
		// Set the token as a cookie (or in a header if needed)
http.SetCookie(w, &http.Cookie{
	Name:     "authToken",
	Value:    tokenStr,
	HttpOnly: true,
	Secure:   true, // true in production (HTTPS only)
	Path:     "/",
	SameSite: http.SameSiteLaxMode, // or Strict/None depending on your frontend/backend setup
})

// Redirect to frontend (your admin/home page)
http.Redirect(w, r, "http://localhost:5173/admin/home", http.StatusSeeOther)


	}
}
// Helper: exchange code for access token
func exchangeCodeForToken(clientID, clientSecret, code string) (*GitHubAccessTokenResponse, error) {
	data := url.Values{}
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("code", code)

	req, err := http.NewRequest("POST", "https://github.com/login/oauth/access_token", bytes.NewBufferString(data.Encode()))
	if err != nil {
		log.Error().Err(err).Msg("Failed to create token exchange request")
		return nil, err
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	// Log request details
	log.Debug().
		Str("url", req.URL.String()).
		Str("payload", data.Encode()).
		Msg("Sending token exchange request")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		log.Error().Err(err).Msg("Failed to execute token exchange request")
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		log.Error().
			Int("status_code", resp.StatusCode).
			Str("response_body", string(body)).
			Msg("GitHub token exchange returned non-200 status")
		return nil, fmt.Errorf("token exchange failed with status %d: %s", resp.StatusCode, string(body))
	}

	var tokenResp GitHubAccessTokenResponse
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		log.Error().Err(err).Msg("Failed to decode token response")
		return nil, err
	}

	if tokenResp.AccessToken == "" {
		log.Error().Msg("GitHub token exchange returned empty access token")
		return nil, fmt.Errorf("empty access token received from GitHub")
	}

	return &tokenResp, nil
}

// Helper: fetch GitHub user using access token
func fetchGitHubUser(accessToken string) (*GitHubUser, error) {
	req, err := http.NewRequest("GET", "https://api.github.com/user", nil)
	if err != nil {
		log.Error().Err(err).Msg("Failed to create user fetch request")
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/vnd.github+json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		log.Error().Err(err).Msg("Failed to fetch GitHub user")
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		log.Error().
			Int("status_code", resp.StatusCode).
			Str("response_body", string(body)).
			Msg("GitHub user fetch returned non-200 status")
		return nil, fmt.Errorf("user fetch failed with status %d: %s", resp.StatusCode, string(body))
	}

	var user GitHubUser
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Error().Err(err).Msg("Failed to read user response body")
		return nil, err
	}
	if err := json.Unmarshal(body, &user); err != nil {
		log.Error().Err(err).Str("response_body", string(body)).Msg("Failed to decode user response")
		return nil, err
	}

	if user.Login == "" {
		log.Error().Str("response_body", string(body)).Msg("GitHub user response has empty login")
		return nil, fmt.Errorf("empty login in GitHub user response")
	}

	return &user, nil
}