package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"go-backend/models"
	"go-backend/utils"

	"go.mongodb.org/mongo-driver/bson"
)

// GetComments godoc
// @Summary      Get all comments
// @Description  Returns a list of all comments
// @Tags         comments
// @Produce      json
// @Success      200  {array}   models.Comment
func GetComments(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	cursor, err := utils.MongoDB.Collection("comments").Find(ctx, bson.M{})
	if err != nil {
		http.Error(w, fmt.Sprintf("Error fetching comments: %v", err), http.StatusInternalServerError)
		return
	}
	defer cursor.Close(ctx)

	var comments []models.Comment
	if err := cursor.All(ctx, &comments); err != nil {
		http.Error(w, fmt.Sprintf("Error decoding comments: %v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(comments)
}

// CreateComment godoc
// @Summary      Create a new comment
// @Description  Adds a new comment to the database
// @Tags         comments
// @Accept       json
// @Produce      json
func CreateComment(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var comment models.Comment
	if err := json.NewDecoder(r.Body).Decode(&comment); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	comment.CreatedAt = time.Now()

	_, err := utils.MongoDB.Collection("comments").InsertOne(ctx, comment)
	if err != nil {
		http.Error(w, "Failed to create comment", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(map[string]string{"message": "Comment added"})
}
