package handlers

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"go-backend/models"
	"go-backend/utils"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

// GetTypes godoc
// @Summary      Get all types
// @Description  Returns a list of all blog content types
// @Tags         types
// @Produce      json
// @Success      200  {array}   models.Type
// @Failure      500  {object}  map[string]string
// @Router       /types [get]
func GetTypes(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	cursor, err := utils.MongoDB.Collection("types").Find(ctx, bson.M{})
	if err != nil {
		http.Error(w, "Failed to fetch types", http.StatusInternalServerError)
		return
	}
	defer cursor.Close(ctx)

	var types []models.Type
	if err := cursor.All(ctx, &types); err != nil {
		http.Error(w, "Failed to decode types", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(types)
}

// CreateType godoc
// @Summary      Create a new type
// @Description  Creates a new blog type with a generated TypeID
// @Tags         types
// @Accept       json
// @Produce      json
// @Param        type  body      models.Type  true  "Type object"
// @Success      201   {object}  models.Type
// @Failure      400   {object}  map[string]string
// @Failure      500   {object}  map[string]string
// @Router       /types [post]
func CreateType(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var newType models.Type
	if err := json.NewDecoder(r.Body).Decode(&newType); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	newType.Name = strings.TrimSpace(newType.Name)
	if newType.Name == "" {
		http.Error(w, "Name is required", http.StatusBadRequest)
		return
	}

	typeID, err := utils.GenerateTypeID(ctx)
	if err != nil {
		http.Error(w, "Failed to generate TypeID", http.StatusInternalServerError)
		return
	}
	newType.ID = primitive.NewObjectID()
	newType.TypeID = typeID

	_, err = utils.MongoDB.Collection("types").InsertOne(ctx, newType)
	if err != nil {
		http.Error(w, "Failed to insert type", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(newType)
}

// DeleteType godoc
// @Summary      Delete a type
// @Description  Deletes a blog type by its TypeID
// @Tags         types
// @Produce      json
// @Param        type_id  path      string  true  "Type ID"
// @Success      200      {object}  map[string]string
// @Failure      400      {object}  map[string]string
// @Failure      404      {object}  map[string]string
// @Failure      500      {object}  map[string]string
// @Router       /types/{type_id} [delete]
func DeleteType(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	typeID := r.PathValue("type_id")
	if typeID == "" {
		http.Error(w, "Missing TypeID", http.StatusBadRequest)
		return
	}

	result, err := utils.MongoDB.Collection("types").DeleteOne(ctx, bson.M{"typeid": typeID})
	if err != nil {
		http.Error(w, "Failed to delete type", http.StatusInternalServerError)
		return
	}

	if result.DeletedCount == 0 {
		http.Error(w, "Type not found", http.StatusNotFound)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"message": "Type deleted successfully"})
}
