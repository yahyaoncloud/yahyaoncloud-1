package handlers

import (
	"encoding/json"
	"net/http"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type AdminCredentials struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func AdminLoginHandler(w http.ResponseWriter, r *http.Request) {
	var creds AdminCredentials
	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	// Simple hardcoded check — move to .env or DB later
	adminEmail := os.Getenv("ADMIN_EMAIL")
	adminPassword := os.Getenv("ADMIN_PASSWORD")

	if creds.Email != adminEmail || creds.Password != adminPassword {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	// Create JWT
	claims := jwt.MapClaims{
		"email": creds.Email,
		"role":  "admin",
		"exp":   time.Now().Add(time.Hour * 24).Unix(), // 24h token
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	secret := os.Getenv("JWT_SECRET")
	signedToken, err := token.SignedString([]byte(secret))
	if err != nil {
		http.Error(w, "Token error", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{
		"authToken": signedToken,
	})
}
