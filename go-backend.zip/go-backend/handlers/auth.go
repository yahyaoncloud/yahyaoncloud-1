package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"

	"github.com/golang-jwt/jwt/v5"
	"github.com/rs/zerolog/log"
)

//@Summary Validate JWT Token
//@Description Validates the JWT token and returns user information
//@Tags auth
//@Accept json
//@Produce json
//@Success 200 {object} map[string]string
//@Failure 401 {string} string "Unauthorized"
//@Router /validate-token [get]
// ValidateTokenHandler validates the JWT token and returns user information
func ValidateTokenHandler(w http.ResponseWriter, r *http.Request) {
	tokenStr := r.Header.Get("Authorization")
	if tokenStr == "" || !strings.HasPrefix(tokenStr, "Bearer ") {
		log.Error().Msg("Missing or invalid Authorization header")
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	tokenStr = strings.TrimPrefix(tokenStr, "Bearer ")
log.Info().Str("authToken", tokenStr).Msg("Received token")

	token, err := jwt.Parse(tokenStr, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(os.Getenv("JWT_SECRET")), nil
	})

	if err != nil || !token.Valid {
		log.Error().Err(err).Msg("Invalid JWT token")
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		log.Error().Msg("Invalid JWT claims")
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	username, _ := claims["username"].(string)
	email, _ := claims["email"].(string)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"username": username,
		"email":    email,
	})
}