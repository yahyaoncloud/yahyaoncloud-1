package handlers

import (
	"context"
	"encoding/json"
	"net/http"
	"time"

	"go-backend/models"
	"go-backend/utils"

	"github.com/gorilla/mux"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

// @Summary Get all posts
// @Description Returns a list of all blog posts
// @Tags posts
// @Produce json
// @Success 200 {array} models.Post
// @Router /posts [get]
func GetPosts(w http.ResponseWriter, r *http.Request) {
    ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
    defer cancel()

    cursor, err := utils.MongoDB.Collection("posts").Find(ctx, bson.M{})
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    var posts []models.Post
    if err := cursor.All(ctx, &posts); err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    json.NewEncoder(w).Encode(posts)
}

// @Summary Create a new post
// @Description Accepts a post object and creates it
// @Tags posts
// @Accept json
// @Produce json
// @Param post body models.Post true "Post to create"
// @Success 200 {object} models.Post
// @Router /posts [post]
func CreatePost(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()

	var post models.Post
	if err := json.NewDecoder(r.Body).Decode(&post); err != nil {
		http.Error(w, "Invalid JSON: "+err.Error(), http.StatusBadRequest)
		return
	}

	post.ID = primitive.NewObjectID()

	postID, err := utils.GeneratePostID(ctx)
	if err != nil {
		http.Error(w, "Failed to generate PostID: "+err.Error(), http.StatusInternalServerError)
		return
	}
	post.PostID = postID

	now := time.Now()
	post.CreatedAt = now
	post.UpdatedAt = now

	_, err = utils.MongoDB.Collection("posts").InsertOne(ctx, post)
	if err != nil {
		http.Error(w, "Database insert failed: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(post)
}


// @Summary Update a post
// @Description Accepts a post object and updates it
// @Tags posts
// @Accept json
// @Produce json
// @Param id path string true "Post ID"
// @Param post body models.Post true "Post to update"
// @Success 200 {object} models.Post
// @Router /posts/{id} [put]
func UpdatePost(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id := vars["id"]

    objID, err := primitive.ObjectIDFromHex(id)
    if err != nil {
        http.Error(w, "Invalid ID", http.StatusBadRequest)
        return
    }

    var post models.Post
    if err := json.NewDecoder(r.Body).Decode(&post); err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }
    post.ID = objID
    post.UpdatedAt = time.Now()

    _, err = utils.MongoDB.Collection("posts").UpdateOne(context.Background(), bson.M{"_id": objID}, bson.M{"$set": post})
    if err != nil {
        http.Error(w, "Failed to update", http.StatusInternalServerError)
        return
    }
    
    w.Header().Set("Content-Type", "application/json; charset=utf-8")

    json.NewEncoder(w).Encode(post)
}   

// @Summary Delete a post
// @Description Deletes a post by ID
// @Tags posts
// @Param id path string true "Post ID"
// @Success 204 "No Content"
// @Failure 400 "Bad Request"
// @Failure 500 "Internal Server Error"
// @Produce json        
// @Router /posts/{id} [delete]
func DeletePost(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id := vars["id"]

    objID, err := primitive.ObjectIDFromHex(id)
    if err != nil {
        http.Error(w, "Invalid ID", http.StatusBadRequest)
        return
    }

    _, err = utils.MongoDB.Collection("posts").DeleteOne(context.Background(), bson.M{"_id": objID})
    if err != nil {
        http.Error(w, "Failed to delete", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusNoContent)
}

// @Summary Get a post by ID
// @Description Returns a single post by ID
// @Tags posts
// @Param id path string true "Post ID"
// @Produce json
// @Success 200 {object} models.Post
// @Failure 404 "Not Found"
// @Failure 500 "Internal Server Error"
// @Router /posts/{id} [get]
func GetPostByID(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id := vars["id"]

    objID, err := primitive.ObjectIDFromHex(id)
    if err != nil {
        http.Error(w, "Invalid ID", http.StatusBadRequest)
        return
    }

    var post models.Post
    err = utils.MongoDB.Collection("posts").FindOne(context.Background(), bson.M{"_id": objID}).Decode(&post)
    if err != nil {
        if err == mongo.ErrNoDocuments {
            http.Error(w, "Post not found", http.StatusNotFound)
        } else {
            http.Error(w, err.Error(), http.StatusInternalServerError)
        }
        return
    }

    w.Header().Set("Content-Type", "application/json; charset=utf-8")

    json.NewEncoder(w).Encode(post)
}


// @Summary Search posts
// @Description Search posts by query, category, tags, or type
// @Tags posts
// @Accept json
// @Produce json
// @Param q query string false "Text search query (title, content)"
// @Param cat query []string false "Category ID array"
// @Param tag query []string false "Tag ID array"
// @Param type query []string false "Type ID array"
// @Success 200 {array} models.Post
// @Failure 500 {string} string "Internal Server Error"
// @Router /posts/search [get]
func SearchPosts(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	query := bson.M{}

	// Text search
	text := r.URL.Query().Get("q")
	if text != "" {
		query["$or"] = bson.A{
			bson.M{"title": bson.M{"$regex": text, "$options": "i"}},
			bson.M{"content": bson.M{"$regex": text, "$options": "i"}},
		}
	}

	// Category ID filter
	catIDs := r.URL.Query()["cat"]
	if len(catIDs) > 0 {
		query["CatIDs"] = bson.M{"$in": catIDs}
	}

	// Tag ID filter
	tagIDs := r.URL.Query()["tag"]
	if len(tagIDs) > 0 {
		query["tagIds"] = bson.M{"$in": tagIDs}
	}

	// Type ID filter
	typeIDs := r.URL.Query()["type"]
	if len(typeIDs) > 0 {
		query["typeIds"] = bson.M{"$in": typeIDs}
	}

	cursor, err := utils.MongoDB.Collection("posts").Find(ctx, query)
	if err != nil {
		http.Error(w, "Database query failed: "+err.Error(), http.StatusInternalServerError)
		return
	}

	var posts []models.Post
	if err := cursor.All(ctx, &posts); err != nil {
		http.Error(w, "Failed to parse posts: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(posts)
}




// @Summary Get posts by category
// @Description Retrieve posts filtered by a specific category ID
// @Tags posts
// @Accept json
// @Produce json
// @Param id path string true "Category ID"
// @Success 200 {array} models.Post
// @Failure 500 {string} string "Internal Server Error"
// @Router /posts/category/{id} [get]
func GetPostsByCategory(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	catID := vars["id"]

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	filter := bson.M{"catIds": bson.M{"$in": []string{catID}}}

	cursor, err := utils.MongoDB.Collection("posts").Find(ctx, filter)
	if err != nil {
		http.Error(w, "Database error: "+err.Error(), http.StatusInternalServerError)
		return
	}
	defer cursor.Close(ctx)

	var posts []models.Post
	if err := cursor.All(ctx, &posts); err != nil {
		http.Error(w, "Cursor decode error: "+err.Error(), http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(posts)
}
