go-backend/
├── main.go
├── go.mod
├── go.sum
├── utils/
│   └── db.go
├── routes/
│   └── routes.go
├── handlers/
│   └── posts.go
├── models/
│   └── post.go
└── .env


go-backend/
│   .env
│   go.mod
│   go.sum
│   main.go
│   Notes.md
│   
├───docs
│       docs.go
│       swagger.json
│       swagger.yaml
│
├───handlers
│       admin.go
│       categories.go
│       comments.go
│       portfolio.go
│       posts.go
│       tags.go
│
├───middleware
│       auth.go
│       postsByCategory.go
│
├───models
│       categories.go
│       comments.go
│       portfolio.go
│       post.go
│       tags.go
│
├───routes
│       routes.go
│
└───utils
        db.go
        GenerateIDs.go

