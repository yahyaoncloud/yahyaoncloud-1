// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"
// 	"strconv"
// 	"strings"
// 	"time"

// 	"go.mongodb.org/mongo-driver/bson"
// 	"go.mongodb.org/mongo-driver/mongo"
// 	"go.mongodb.org/mongo-driver/mongo/options"
// )

// type Tag struct {
// 	ID    string `bson:"_id"`
// 	TagID string `bson:"tagID"`
// 	Name  string `bson:"name"`
// }

// func formatTagID(n int) string {
// 	return fmt.Sprintf("t%07d", n)
// }

// func main() {
// 	uri := "mongodb+srv://ykinwork1:Almightypush%40123@blogdb.5oxjqec.mongodb.net/"
// 	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	defer cancel()

// 	client, err := mongo.Connect(ctx, options.Client().ApplyURI(uri))
// 	if err != nil {
// 		log.Fatalf("MongoDB connection error: %v", err)
// 	}
// 	defer client.Disconnect(ctx)

// 	collection := client.Database("blog").Collection("tags")

// 	cursor, err := collection.Find(ctx, bson.M{})
// 	if err != nil {
// 		log.Fatalf("Failed to fetch tags: %v", err)
// 	}
// 	defer cursor.Close(ctx)

// 	var tags []Tag
// 	if err := cursor.All(ctx, &tags); err != nil {
// 		log.Fatalf("Failed to decode tags: %v", err)
// 	}

// 	seen := make(map[string]bool)
// 	updated := 0

// 	for _, tag := range tags {
// 		originalTagID := tag.TagID

// 		// If already correctly formatted, skip
// 		if strings.HasPrefix(originalTagID, "t") {
// 			seen[originalTagID] = true
// 			continue
// 		}

// 		// Convert numeric tagID like "5" to int
// 		num, err := strconv.Atoi(originalTagID)
// 		if err != nil {
// 			log.Printf("Skipping tag with invalid tagID %s: %v", originalTagID, err)
// 			continue
// 		}

// 		newTagID := formatTagID(num)

// 		if seen[newTagID] {
// 			log.Printf("Skipping duplicate formatted tagID %s for tag %s", newTagID, tag.Name)
// 			continue
// 		}

// 		// Update tagID in MongoDB
// 		_, err = collection.UpdateOne(ctx, bson.M{"_id": tag.ID}, bson.M{
// 			"$set": bson.M{"tagID": newTagID},
// 		})
// 		if err != nil {
// 			log.Printf("Failed to update tagID for %s: %v", tag.Name, err)
// 			continue
// 		}

// 		log.Printf("✅ Updated tag '%s': %s ➡ %s", tag.Name, originalTagID, newTagID)
// 		seen[newTagID] = true
// 		updated++
// 	}

// 	log.Printf("🎯 %d tagIDs were reformatted successfully.", updated)
// }
