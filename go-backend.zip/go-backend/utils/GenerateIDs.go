package utils

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func getNextNumericSuffix(prefix, field, collectionName string, length int, ctx context.Context) (string, error) {
	if MongoDB == nil {
		return "", fmt.Errorf("MongoDB not initialized")
	}

	collection := MongoDB.Collection(collectionName)
	opts := options.FindOne().SetSort(bson.D{{field, -1}})
	var result bson.M

	err := collection.FindOne(ctx, bson.M{
		field: bson.M{"$regex": "^" + prefix + "\\d+$"},
	}, opts).Decode(&result)
	if err != nil && err != mongo.ErrNoDocuments {
		return "", err
	}

	var maxID int
	if existingID, ok := result[field].(string); ok {
		numPart := strings.TrimPrefix(existingID, prefix)
		maxID, _ = strconv.Atoi(numPart)
	}

	newID := fmt.Sprintf("%s%0*d", prefix, length, maxID+1)
	return newID, nil
}


// ===== Specific Generators =====

func GeneratePostID(ctx context.Context) (string, error) {
	return getNextNumericSuffix("p", "PostID", "posts", 7, ctx)
}

func GenerateCatID(ctx context.Context) (string, error) {
	return getNextNumericSuffix("c", "CatID", "categories", 2, ctx)
}

func GenerateTagID(ctx context.Context) (string, error) {
	return getNextNumericSuffix("t", "TagID", "tags", 2, ctx)
}

func GenerateTypeID(ctx context.Context) (string, error) {
	return getNextNumericSuffix("y", "TypeID", "types", 2, ctx)
}
