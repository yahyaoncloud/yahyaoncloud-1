package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Post struct {
    ID         primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    PostID    string             `bson:"postId,omitempty" json:"postId"`
    Title      string             `json:"title"`
    Content    string             `json:"content"`
    Summary    string             `json:"summary"`
    Date       string             `json:"date"`
    AuthorID   string             `json:"authorId"`
	CatIDs     []string          `bson:"catIds,omitempty" json:"catIds"` 
    Categories []Category         `json:"categories,omitempty"`
    TagIDs     []string          `bson:"tagIds,omitempty" json:"tagIds"` 
    Tags       []Tag             `json:"tags,omitempty"`
    TypeIDs    []string          `bson:"typeIds,omitempty" json:"typeIds"` 
    Types      []Type            `json:"types,omitempty"` 
    CoverImage *MediaAsset        `json:"coverImage,omitempty"`
    Gallery    []MediaAsset       `json:"gallery,omitempty"`
    CreatedAt  time.Time          `json:"createdAt"`
    UpdatedAt  time.Time          `json:"updatedAt"`
}

type MediaAsset struct {
    ID         string    `json:"id"`
    URL        string    `json:"url"`
    AltText    string    `json:"altText,omitempty"`
    UploadedBy string    `json:"uploadedBy"`
    PostID     string    `json:"postId,omitempty"`
    Type       string    `json:"type"`
    CreatedAt  time.Time `json:"createdAt"`
}
