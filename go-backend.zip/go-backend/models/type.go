package models

import "go.mongodb.org/mongo-driver/bson/primitive"

// Article represents general informative content
// Guide represents instructional content
// News represents time-sensitive updates
// Tutorial represents focused learning content
// CaseStudy represents a real-world use case or success story
// Review represents a rating/comment on something
// FAQ represents a frequently asked question

type Type struct {
	ID       primitive.ObjectID      `json:"id" gorm:"primaryKey"`
	TypeID	 string    `json:"type_id"`
	Name	 string    `json:"name"`
}