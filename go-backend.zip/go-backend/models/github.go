package models

import "go.mongodb.org/mongo-driver/bson/primitive"

type GitHubUser struct {
	ID       primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	GithubID string             `bson:"githubId,omitempty" json:"githubId"`
	Username string `json:"username"`
	Email    string `json:"email"`
	Name     string `json:"name"`
}