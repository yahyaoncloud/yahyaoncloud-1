package models

import (
	"time"
)

type Comment struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	PostIhD    uint      `json:"post_id"`           // ID of the blog post
	UserID    uint      `json:"user_id"`           // ID of the user who made the comment
	Content   string    `json:"content"`           // Comment text
	CreatedAt time.Time `json:"created_at"`        // Timestamp of creation
	// UpdatedAt time.Time `json:"updated_at"`        // Timestamp of last update
}